//
//  Main.swift
//  Capy4Fun
//
//  Created by Mputh on 09/12/25.
//

import SwiftUI

@main
struct Capy4FunApp: App {

    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            EmptyView()
        }
    }
}
